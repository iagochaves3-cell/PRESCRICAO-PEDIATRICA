# Revisão documental de cobertura e acesso

Data da checagem: 14/09/2026. Escopo: leitura dos arquivos do Emergência Pediátrica e comparação com os PDFs. Nenhum arquivo de Site foi alterado por esta revisão. Não constitui validação clínica independente dos 1.263 esquemas nem confirmação de disponibilidade comercial atual.

## Resultado verificável

| Verificação | Resultado |
|---|---:|
| Monografias, números 1 a 498, nomes e página de origem | 498/498 |
| Identificadores únicos de esquemas | 1.263/1.263 |
| Campos textuais comparados ao PDF posológico | 6.199 |
| Divergências de texto nos campos comparados | 0 |
| Listas de apresentações comparadas ao catálogo farmacológico | 498/498 |
| Divergências de apresentações | 0 |
| Indicações distintas oferecidas pelo seletor, somadas por medicamento | 1.248 |
| Opções de apresentação, segmentadas por ponto e vírgula | 810 |
| Grupos de indicação literalmente repetida entre variantes | 15 |
| Grupos de apresentação repetida por normalização alfanumérica | 0 |
| Células do nomograma de omalizumabe, incluindo ausência de dose | 140/140 |
| Referências de esquema sem correspondente na monografia | 0 |

Os 6.199 campos compreendem nomes, indicações documentais, monitorização/precauções e, em cada esquema, indicação, população, dose e notas não vazias. A comparação normaliza Unicode e espaços/quebras de linha, preservando os demais caracteres. Todas as apresentações foram localizadas literalmente, após essa mesma normalização, na página indicada do PDF farmacológico.

Também foi feita conferência inversa do texto das 498 páginas de monografia do PDF original. Após remover os campos já mapeados e elementos de paginação, status e referências, não restou conteúdo clínico sem correspondência em 497 páginas. A página de omalizumabe contém o nomograma adicional: a sequência de 140 células do JSON corresponde exatamente à sequência textual do PDF, preservando dose e intervalo; a explicação encontra-se nos campos do nomograma.

As 15 repetições literais são variantes de população ou esquema e o componente usa `Set` para mostrar uma única opção de indicação, mantendo todas as respectivas linhas de dose. Números das monografias: 77, 85, 86, 108, 158, 268, 333, 346, 379, 413, 443, 456 (duas indicações), 458 e 475. Não se deve eliminar essas variantes do conteúdo clínico.

A triagem por similaridade textual identificou pares próximos que expressam diferenças reais: acetilcisteína em duas ou três bolsas; captopril neonatal; apresentações/vias de desmopressina; sais de fluticasona; gravidade de envenenamentos; indução versus manutenção e fases de tratamento. Não foi identificada indicação semanticamente redundante sem diferença de contexto nesta triagem. Isso não representa prova formal da inexistência de toda sinonímia entre 498 monografias.

## Acesso no componente

`app/posology/PosologyLibrary.tsx` disponibiliza todos os medicamentos quando a busca está vazia. A busca considera nome, indicação original, apresentações e indicação/população de cada esquema. A mudança de medicamento ou indicação limpa seleções anteriores. Cada indicação abre todas as linhas correspondentes; não existe filtro de idade que oculte silenciosamente variantes. A cópia inclui doses, notas, precauções, fontes e atualizações aplicáveis. Não encontrei falha concreta de filtragem que torne uma das 1.263 linhas inacessível.

Esta foi inspeção de código e dados, sem ensaio interativo em navegador. Não comprova comportamento visual, área de toque, impressão ou resultado clínico das calculadoras separadas.

A seleção de apresentação é documental: algumas opções agrupam mais de uma concentração quando assim redigidas no PDF. O componente informa que a seleção não confirma compatibilidade com via e esquema e não gera volume individual. A existência de um esquema na consulta não equivale à sua implementação numa calculadora por peso/idade.

## Atualizações: 34 blocos em 28 medicamentos

Todos os identificadores `row_ids` das atualizações correspondem a linhas existentes. Não há bloco de atualização com texto integral repetido.

- Escetamina: três blocos se sobrepõem parcialmente, mas são concordantes. Mantêm a distinção entre escetamina e cetamina racêmica, a não equivalência do spray e a ausência de esquema pediátrico de asma validado nesta pesquisa. A infusão adulta citada não é apresentada como esquema pediátrico.
- Lidocaína: os dois blocos repetem parte da errata de “vasoespasmo” e a exclusão de vasoconstritor para uso antiarrítmico IV. São concordantes e acrescentam distinções de via e formulação.
- Propofol: um bloco delimita anestesia versus UTIP e a referência PANDEM; o outro especifica a apresentação de bolus adotada. Não há contradição entre eles. A precisão do limite numérico é preservada: menos de 4 mg/kg/h não deve ser arredondado para 67 mcg/kg/min.
- Ceftriaxona e fenobarbital também possuem dois blocos, com escopos complementares de população, produto, preparo ou velocidade.

Há redundância editorial em alertas sobre escetamina/lidocaína/propofol. Uma futura fusão editorial pode reduzir leitura repetida, desde que mantenha todas as qualificações, fontes e precedência contextual. Não é duplicação de apresentação ou indicação no seletor.

## Achados acionáveis encaminhados ao responsável

1. No arquivo `deliverables/all_revisions.json` inspecionado, a referência interna de KCl tem `url` vazia. Se usada diretamente pelo componente, `<a href="">` aponta para a página atual. Deve ser convertida em referência interna à página 142 do PDF ou exibida sem hiperlink. O responsável recebeu o achado; conferir o JSON efetivamente publicado após a correção.
2. O download do catálogo estruturado aponta para o conteúdo documental original. As atualizações clínicas estão em arquivo separado. Para preservar as correções na reutilização, disponibilizar explicitamente também esse segundo arquivo, ou incluir as atualizações no pacote de exportação. Não confundir download do original com exportação clínica revisada.
3. As notas de revisão aparecem junto ao texto original. A informação original não foi silenciosamente reescrita. Onde houver dose ou conversão superada, a precedência da revisão deve permanecer explícita no PDF, na consulta e na cópia.

## Conferência adicional solicitada: apresentações injetáveis atribuídas à Folha

| Medicamento | O que o catálogo documenta | Conclusão da atribuição |
|---|---|---|
| Lorazepam, nº 282, PDF posológico p. 294 / base p. 37 | Comprimidos 1 mg e 2 mg; precaução diz que a disponibilidade brasileira do original é VO | Não atribuir 2 ou 4 mg/mL injetável a esse catálogo |
| Ácido valproico / valproato / divalproato, nº 15, p. 27 / base p. 8 | Cápsulas 250 mg; xarope 50 mg/mL; comprimidos 250 e 500 mg; divalproato retardado/prolongado 250 e 500 mg | Não atribuir injetável 100 mg/mL a esse catálogo |
| Fosfenitoína | Não é uma das 498 monografias | Não atribuir 50 mg PE/mL ao catálogo |

Os esquemas de via IV citados em fontes internacionais não demonstram, por si, a apresentação brasileira. Para essas três conversões, o volume deve permanecer indisponível enquanto a concentração do produto efetivamente escolhido não tiver fonte independente adequada. Esta revisão não afirma ausência universal de registro ou comercialização dessas apresentações.

## Limites de conclusão

O documento classifica 992 linhas como `supported`, 262 como `restricted` e 9 como `unresolved`. Essas são classificações documentais, não nove erros inventados pelo site nem certificação independente das demais doses. As nove lacunas são: escetamina/asma; clopidogrel/stents; clorpromazina/coreia de Sydenham; dantroleno/síndrome neuroléptica maligna; ondansetrona/radioterapia; sucralfato/gastrite erosiva; verapamil/hipertensão ou angina; venlafaxina/pânico; acetato de cálcio/DRC. Devem continuar identificadas sem preenchimento automático por analogia.

Evidência reproduzível: `coverage-evidence.json`, `coverage-pdf-remainders.json`, `coverage_check.py` e `coverage_remainders.py` no workspace. As referências às monografias e fontes dos achados acima provêm dos arquivos fornecidos; não foi realizada nova pesquisa externa nesta tarefa de cobertura.
