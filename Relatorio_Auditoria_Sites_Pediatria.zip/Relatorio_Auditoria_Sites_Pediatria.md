# Auditoria e publicação do catálogo pediátrico

Data: 14/09/2026. Publicação confirmada nos sete projetos abaixo. Este relatório registra o que foi realizado e os limites ainda existentes; não certifica validação clínica integral de todos os esquemas.

## Publicações confirmadas

| Site | Versão | Endereço |
|---|---:|---|
| Emergência Pediátrica — Doses e Cálculos | 102 | https://emergencia-pediatrica-doses.iagovalmeida.chatgpt.site |
| Prescrição Pediátrica Segura | 192 | https://prescricao-pediatrica-segura.iagovalmeida.chatgpt.site |
| FOLHA DE PARADA | 39 | https://folha-de-parada.iagovalmeida.chatgpt.site |
| Pediatric Flow — Emergência Pediátrica | 41 | https://pediatric-flow-cdss.iagovalmeida.chatgpt.site |
| Soroterapia Pediátrica | 44 | https://soroterapia-pediatrica.iagovalmeida.chatgpt.site |
| Ventilação Mecânica | 32 | https://ventilacao-mecanica.iagovalmeida.chatgpt.site |
| DERMATOLOGIA | 7 | https://dermatologia.iagovalmeida.chatgpt.site |

Os identificadores de versão, publicação e commit estão em publication-results.json. As sete compilações finais terminaram com sucesso. O PDF incluído nos sete artefatos de publicação corresponde byte a byte ao PDF revisado entregue.

## Cobertura documental

- 498 medicamentos, com nomes de princípios ativos conforme a fonte.
- 1.263 esquemas preservados; 1.248 opções distintas de indicação e 810 grupos de apresentação.
- 6.199 campos textuais comparados, sem divergências após normalização de espaços e Unicode.
- 498 listas de apresentações comparadas ao catálogo farmacológico complementar, sem divergências.
- Nomograma de omalizumabe: 140 células preservadas.
- Indicações repetidas literalmente aparecem uma vez no seletor; variantes clínicas e populacionais permanecem disponíveis.

As apresentações provêm do catálogo farmacológico consolidado complementar de 61 páginas, pois o PDF posológico de 510 páginas não contém uma lista completa de apresentações. A correspondência documental não comprova comercialização atual de todos os produtos no Brasil. Algumas opções mantêm concentrações agrupadas, tal como escritas na fonte.

## PDF revisado e sincronização

Foram incorporados 38 blocos de revisão em 32 medicamentos, dentro das respectivas fichas. Mantidas as 510 páginas, com extensão vertical das páginas afetadas para preservar o conteúdo anterior. O texto original, regiões visuais e links foram conferidos: nenhuma divergência. Os 500 links internos do índice foram preservados. As revisões têm precedência explícita sobre trechos anteriores superados; o histórico não foi apagado nem substituído silenciosamente.

SHA-256 do PDF entregue: 0588daf15ef394a3720dea2f91d7e3f0dde0dccb19d3d3df053e8092df35b961.

A versão revisada foi salva como nova versão do documento de referência. Isso não constitui instalação automática de memória ou propagação para todos os projetos e conversas do ChatGPT.

Todos os sete sites receberam a mesma consulta consolidada e revisões, com acesso aos arquivos de dados originais e de atualizações. A mudança de medicamento limpa a seleção anterior. A apresentação documental não gera automaticamente um volume de prescrição sem contexto validado.

## Correções operacionais principais

- Cálcio: unidades de cálcio elementar, concentração específica do produto, tetos por indicação, diluição, acesso, tempo, vazão e conferência reversa alinhados nos fluxos alterados.
- Magnésio: opção operacional BCEHS explicitada e sincronizada nos fluxos alterados; preservada a reversa da bomba nas apresentações da Folha.
- KCl: concentração e retirada do diluente corrigidas nos registros específicos de Prescrição e Pediatric Flow para manter o volume final declarado.
- Folha: seleção do contexto de cálcio, preparo completo, faixa etária do propofol, fonte do preparo da noradrenalina e distinção entre cetamina e escetamina.
- Removida atribuição incorreta ao catálogo de apresentações injetáveis de lorazepam, valproato e fosfenitoína. Conversões sem suporte permanecem indisponíveis.
- Preservadas e consolidadas as revisões concomitantes de amoxicilina/clavulanato, metronidazol, somatropina e tadalafila.

Os textos e referências primárias de cada revisão estão em all_revisions.json e nas respectivas fichas do PDF. As mudanças de calculadoras são específicas aos fluxos identificados; a presença da consulta completa não significa implementação automática dos 1.263 esquemas em todos os motores antigos.

## Evidências e verificação

Suítes completas: Emergência 323 testes aprovados; Prescrição 457; Folha 53; Pediatric Flow 136; Soroterapia 39; Ventilação 24. Dermatologia: 36 testes clínicos e 18 outros aprovados. Após a integração das quatro revisões concomitantes, 16 testes direcionados da Emergência também passaram. Os testes do catálogo compartilhado passaram nos sete projetos. Não somar estes números como testes clínicos independentes: existem verificações sobrepostas.

As sete compilações finais e verificações de tipos passaram. Lint direcionado da Emergência passou; Folha apresentou apenas um aviso preexistente de variável não utilizada. Não foi executado lint global em todos os projetos.

Foram realizados comparação documental, testes dimensionais/reversos dos cálculos alterados e revisão de integração. Essas etapas não equivalem a três revisores clínicos independentes de cada posologia.

Inspeção visual de páginas revisadas do PDF aprovada. Na prévia da Emergência, consulta, troca de medicamento e limpeza de seleção foram verificadas. A cópia para clipboard não pôde ser confirmada no contexto HTTP da prévia, com falha informada corretamente pela interface. Não houve ensaio móvel completo nem auditoria interativa de todas as rotas em produção. A confirmação de publicação é a resposta do serviço de hospedagem.

## Resolução dos achados intermediários

clinical-review.md e coverage-review.md são fotografias anteriores da auditoria, conservadas para rastreabilidade. Seus achados não descrevem todos o estado final:

1. Acesso central na cópia do cálcio: campo de acesso passou a integrar o plano e as notas.
2. Magnésio operacional: protocolo BCEHS selecionado explicitamente nos fluxos alterados.
3. Propofol na Folha: exigência de idade e mínimo de 36 meses no contexto adotado.
4. Cálcio na Folha: diluente, volume final, tempo e bomba individualizados.
5. Magnésio alternativo na Folha: conferência reversa da vazão preservada.
6. Noradrenalina na Folha: fonte do preparo Hypofarma exibida junto à fonte da dose.
7. Referência interna de KCl sem URL: exibida como texto, sem link vazio.
8. Exportação: arquivo das revisões disponibilizado junto ao catálogo documental; precedência das revisões explícita.
9. Contagem intermediária de 34 revisões em 28 medicamentos atualizada para 38 em 32 após integração de mudanças concorrentes.

## Pendências que impedem afirmar conclusão clínica global

A fonte contém nove esquemas classificados como não resolvidos: escetamina/asma; clopidogrel/stents; clorpromazina/coreia de Sydenham; dantroleno/síndrome neuroléptica maligna; ondansetrona/radioterapia; sucralfato/gastrite erosiva; verapamil/hipertensão ou angina; venlafaxina/pânico; acetato de cálcio/DRC. Foram preservados como lacunas, sem inventar dose por analogia.

As classificações documentais são 992 supported, 262 restricted e nove unresolved. Não representam validação clínica externa das outras 1.254 linhas. Também não houve comprovação regulatória e comercial brasileira atual de cada apresentação, nem validação automática integral de todos os motores de todos os projetos do usuário. Há alertas editoriais parcialmente sobrepostos, embora as opções de indicação e apresentação estejam deduplicadas.

Portanto, a consolidação documental e as publicações descritas foram concluídas; o pedido de certificação clínica integral e sincronização de absolutamente todos os cálculos/projetos permanece além do escopo efetivamente verificado. O relatório não declara ausência absoluta de erros.
