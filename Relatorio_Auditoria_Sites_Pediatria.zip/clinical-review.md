# Revisão independente da integração clínica

Data: 14/09/2026. Escopo: leitura de código e execução direta de cálculos existentes, confrontados com as oito notas recuperadas do PDF. Não houve pesquisa externa nova, edição de Sites ou publicação. Este relatório não representa validação clínica integral.

## Problemas concretos

1. **Alta prioridade — EPD, acesso central omitido na cópia de cálcio para hipercalemia instável.** Em `intermittent-dilutions.json`, o preparo sem diluição adicional a 0,2325 mmol/mL declara `access: central seguro; ECG e ressuscitação disponíveis`. Entretanto, `parenteral-preparation.ts` não transporta `recipe.access` para a linha copiável, título ou notas. O label do preparo estável já menciona central; o do instável não. Reprodução: 12 kg → 1,8 mmol, aspirar 7,7419 mL, “sem diluição adicional”, 2 min, 232,2581 mL/h, sem exigência de acesso central na cópia. É perda de condição explícita do próprio preparo. Correção: incluir `recipe.access` na cópia e na apresentação do plano, antes de liberar essa opção.

2. **Prioridade moderada — magnésio do PDF ainda não corresponde à opção operacional do EPD.** `operationalParenteralResolution` mantém tratamento especial do registro 122: 40 mg/kg (máximo 2.000 mg) em 20 minutos, >2 anos. O perfil intermitente oferece 20 e 40 mg/mL em 20 minutos. A nota consolidada do PDF e a Folha adotam especificamente BCEHS: 50 mg/kg, máximo 2.000 mg, 40 mg/mL, 15 minutos. A coexistência de protocolos pode ser válida, mas não é sincronização completa do esquema BCEHS: em 20 kg, o EPD operacional gera 800 mg; BCEHS gera 1.000 mg. Não chamar o esquema de 40 mg/kg/20 min de erro clínico sem verificar sua fonte própria. Incluir uma opção BCEHS explícita ou identificar claramente a alternativa e alinhar o escopo de cada opção.

3. **Prioridade moderada — propofol da Folha não aplica limite etário do contexto adotado.** `propofol-iot` usa somente 1% (correto), porém não define `requiresAge` ou `minAgeMonths`. A interface bloqueia neonatos globalmente, mas permite o item de 1 mês a menos de 3 anos e com idade não informada. O PDF-base qualifica a anestesia com a bula adotada a partir de 3 anos. O cálculo genérico 1–2 mg/kg não identifica um regime off-label para menores de 3 anos nem fonte própria que o sustente. Correção: aplicar o limite do contexto adotado, ou estabelecer um ramo off-label explicitamente sustentado e separado. Não inferir que as doses são proibidas em todo contexto ou todo produto.

4. **Lacuna de completude — cálcio da Folha mantém volumes corretos, mas não entrega preparo e bomba completos individualizados.** Hipocalcemia em 20 kg retorna 2,2 mmol, 9,462 mL do estoque e 50 mL finais; o diluente permanece como fórmula em texto e não há vazão calculada. Com o tempo escolhido de 10 min, os valores derivados são 40,537634 mL de diluente e 300 mL/h. Hipercalemia no teto retorna 6,6 mmol/28,387 mL, mas estabilidade, tempo mínimo calculado e bomba ficam somente em instruções gerais. Isso não é erro nas conversões existentes; é diferença em relação à solicitação de uma linha completa para cada contexto.

5. **Baixa prioridade — reversa da bomba de magnésio desaparece na apresentação alternativa da Folha.** A ampola 50% mantém a reversa `100 mL/h × 0,25 h × 40 mg/mL = 1.000 mg` no exemplo de 20 kg. Ao selecionar 10%, `calculateForPresentation` sobrescreve `preparedReverse` por uma conferência dose/concentração final e deixa de expor a reversa da bomba. A dose, o volume e a vazão continuam corretos (1.000 mg, aspirar 10 mL, 25 mL finais, 100 mL/h). Preservar também a reversa da vazão para manter a checagem equivalente entre apresentações.

6. **Baixa prioridade — identificação bibliográfica do preparo da noradrenalina na Folha.** Texto do preparo especifica corretamente Hypofarma, SG5%, base/sal e uso pediátrico off-label; o link primário do item permanece Starship. O vínculo direto com a bula Hypofarma deve aparecer na fonte do preparo, além da fonte pediátrica da dose. Não foi identificada divergência matemática.

## Conferências que passaram

- EPD, registros 59 e 60: oito cenários executados com 12, 40, 44 e 100 kg. O parser preservou mmol de cálcio elementar, concentração 0,2325 mmol/mL e tetos distintos de 6,6 e 4,4 mmol. Não houve reutilização dos fatores internacionais 0,5/0,68 mL/kg.
- Hipocalcemia, 12 kg: 1,32 mmol; estoque 5,677419 mL; diluente 24,322581 mL; final 30 mL a 0,044 mmol/mL; 10 min; 180 mL/h; reversa 1,32 mmol.
- Hipocalcemia no teto (≥40 kg): 4,4 mmol; estoque 18,924731 mL; final 100 mL; 10 min; 600 mL/h; reversa 4,4 mmol.
- Hipercalemia, 12 kg: 1,8 mmol; estoque/final 7,741935 mL no preparo central sem diluente; opção estável 15 min/30,967742 mL/h; instável 2 min/232,258065 mL/h.
- Hipercalemia no teto (≥44 kg): 6,6 mmol; estoque/final 28,387097 mL; estável 15 min/113,548387 mL/h; instável estendido para 5,677419 min/300 mL/h. O limite de 5 mL/min de estoque é respeitado pelo algoritmo. O PDF arredonda conservadoramente esse mínimo para 5,678 min.
- Folha, magnésio em 20 kg: ambas as ampolas mantêm 1.000 mg, 25 mL finais, 15 min e 100 mL/h. Apenas o volume aspirado muda: 2 mL a 500 mg/mL ou 10 mL a 100 mg/mL.
- Folha, noradrenalina em 20 kg: 4 mL a 1 mg/mL de base + 96 mL de SG5% = 100 mL a 40 mcg/mL. Doses 0,05/0,1/1 mcg/kg/min retornam 1,5/3/30 mL/h. Reversas coerentes.
- Folha, propofol: apresentação 2% removida da seleção de bolus; 1% = 10 mg/mL é coerente dimensionalmente. Permanece a questão etária acima.
- Folha, cetamina em infusão: não gera mL ou mL/h de escetamina a partir da faixa de cetamina racêmica. A mensagem conserva a distinção entre princípios ativos e a lacuna da asma no PDF.

## Limites

Não houve inspeção visual da interface, auditoria de todas as rotas ou nova consulta de bulas/diretrizes. A leitura de dados e a execução direta dos motores não substituem a verificação de navegação/copiar/selecionar na interface. As ressalvas clínicas são de adequação ao contexto das fontes já incorporadas; não foram criadas doses novas.

## Arquivos lidos e SHA-256

- `/workspace/sites/emergencia-pediatrica-doses/app/data/clinical-data.json`: `30fe93057e8ee9c351b616659cc31f8dfb9219c8cfc1cb9c044ba82c729b738e`
- `/workspace/sites/emergencia-pediatrica-doses/app/parenteral-preparation.ts`: `cdb07a22500ba921cf448acfbc2358d139afe443847d7d4c4b2ecceccce62fee`
- `/workspace/sites/emergencia-pediatrica-doses/app/data/intermittent-dilutions.json`: `912fa744ef32def740347215d65a1c4e2222632ea392b76da514f296c05fd980`
- `/workspace/sites/emergencia-pediatrica-doses/app/page.tsx`: `66283abbde094d4541eeefc9bc5069410fc6ff8026d9ec0c159e8e2a021ab58d`
- `/workspace/sites/folha-de-parada/app/clinical-data.ts`: `c3d088934046125f2079fd8464faf42bc6cc475b03ea44473b9f2005c6851480`
- `/workspace/sites/folha-de-parada/app/page.tsx`: `64c9fc5ff61bee4a30c68d39a1d805ad1f16ec543eb9ab46eb9439c94209496c`
